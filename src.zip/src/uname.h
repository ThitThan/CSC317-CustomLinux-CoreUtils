/* This is for the 'uname' program. */
#define UNAME_UNAME 1

/* This is for the 'arch' program.  */
#define UNAME_ARCH 2

extern int uname_mode;
